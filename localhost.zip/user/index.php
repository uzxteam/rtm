
<?php include_once "header.php"; ?>
        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="container-fluid mt-3">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <a href="asaryukla.php">
                        <div class="card gradient-1">
                            <div class="card-body">
                                <h3 class="text-white">Asar</h3>
                               
                                <span class="float-right display-5 opacity-5"><i class="fa fa-book"></i></span>
                            </div>
                        </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                    <a href="asaryukla.php">
                        <div class="card gradient-2">
                            <div class="card-body">
                                <h3 class="text-white">Roman</h3>
                                
                                <span class="float-right display-5 opacity-5"><i class="fa fa-book"></i></span>
                            </div>
                        </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                    <a href="asaryukla.php">
                        <div class="card gradient-3">
                            <div class="card-body">
                                <h3 class="text-white">Qissa</h3>
                               
                                <span class="float-right display-5 opacity-5"><i class="fa fa-book"></i></span>
                            </div>
                        </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                    <a href="asaryukla.php">
                        <div class="card gradient-4">
                            <div class="card-body">
                                <h3 class="text-white">Hikoya</h3>
                              
                                <span class="float-right display-5 opacity-5"><i class="fa fa-book"></i></span>
                            </div>
                        </div>
                        </a>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                    <a href="asaryukla.php">
                        <div class="card gradient-5">
                            <div class="card-body">
                                <h3 class="text-white">Darslik</h3>
                               
                                <span class="float-right display-5 opacity-5"><i class="fa fa-book"></i></span>
                            </div>
                        </div>
                        </a>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                    <a href="asaryukla.php">
                        <div class="card gradient-6">
                            <div class="card-body">
                                <h3 class="text-white">Qo'llanma</h3>
                                
                                <span class="float-right display-5 opacity-5"><i class="fa fa-book"></i></span>
                            </div>
                        </div>
                        </a>
                    </div>
                    
                </div>

               
                

            </div> 
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <?php include_once "footer.php"; ?>